using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using PimDeWitte.UnityMainThreadDispatcher;

public class TCPIPServerAsync : MonoBehaviour
{
    System.Threading.Thread SocketThread;
    volatile bool keepReading = false;

    public GameObject carObject;  
    public float speed = 1.0f;    

    private Vector3 targetPosition;
    private bool shouldMove = false;

    void Start()
    {
        Application.runInBackground = true;
        targetPosition = carObject.transform.position;
        startServer();
    }

    void Update()
    {
        if (shouldMove)
        {
            carObject.transform.position = Vector3.MoveTowards(carObject.transform.position, targetPosition, speed * Time.deltaTime);

            if (Vector3.Distance(carObject.transform.position, targetPosition) < 0.01f)
            {
                carObject.transform.position = targetPosition;
                shouldMove = false;
            }
        }
    }

    void startServer()
    {
        SocketThread = new System.Threading.Thread(networkCode);
        SocketThread.IsBackground = true;
        SocketThread.Start();
    }

    private string getIPAddress()
    {
        IPHostEntry host;
        string localIP = "";
        host = Dns.GetHostEntry(Dns.GetHostName());
        foreach (IPAddress ip in host.AddressList)
        {
            if (ip.AddressFamily == AddressFamily.InterNetwork)
            {
                localIP = ip.ToString();
            }
        }
        return localIP;
    }

    Socket listener;
    Socket handler;

    void networkCode()
    {
        string data = "";

        byte[] bytes = new Byte[1024];
        IPAddress IPAdr = IPAddress.Parse("127.0.0.1");
        IPEndPoint localEndPoint = new IPEndPoint(IPAdr, 1107);

        listener = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

        try
        {
            listener.Bind(localEndPoint);
            listener.Listen(10);

            while (true)
            {
                keepReading = true;
                Debug.Log("Waiting for Connection");

                handler = listener.Accept();
                Debug.Log("Client Connected");
                data = null;

                byte[] SendBytes = System.Text.Encoding.Default.GetBytes("I will send key");
                handler.Send(SendBytes);

                while (keepReading)
                {
                    bytes = new byte[1024];
                    int bytesRec = handler.Receive(bytes);

                    if (bytesRec <= 0)
                    {
                        keepReading = false;
                        handler.Disconnect(true);
                        break;
                    }

                    data += System.Text.Encoding.ASCII.GetString(bytes, 0, bytesRec);
                    Debug.Log("Received from Client: " + data);

                    string[] messages = data.Split('\n');
                    foreach (var message in messages)
                    {
                        if (!string.IsNullOrWhiteSpace(message))
                        {
                            Debug.Log("Processing message: " + message);
                            if (message.StartsWith("Step"))
                            {
                                string positionString = message.Split(':')[2].Trim();
                                Vector3 position = ParsePosition(positionString);
                                Debug.Log("Car position: " + position);
                                UpdateCarPosition(position);
                            }
                        }
                    }

                    data = "";

                    System.Threading.Thread.Sleep(1);
                }

                System.Threading.Thread.Sleep(1);
            }
        }
        catch (Exception e)
        {
            Debug.Log(e.ToString());
        }
    }

    void stopServer()
    {
        keepReading = false;

        if (SocketThread != null)
        {
            SocketThread.Abort();
        }

        if (handler != null && handler.Connected)
        {
            handler.Disconnect(false);
            Debug.Log("Disconnected!");
        }
    }

    void OnDisable()
    {
        stopServer();
    }

    Vector3 ParsePosition(string positionString)
    {
        positionString = positionString.Trim('(', ')');
        string[] parts = positionString.Split(',');
        float x = float.Parse(parts[0].Trim());
        float z = float.Parse(parts[1].Trim());
        return new Vector3(x, 0, z);
    }

    void UpdateCarPosition(Vector3 newPosition)
    {
        UnityMainThreadDispatcher.Instance().Enqueue(() =>
        {
            targetPosition = newPosition;
            shouldMove = true;
        });
    }
}
